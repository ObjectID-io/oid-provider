"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getObjectIdsByType = getObjectIdsByType;
exports.getObject = getObject;
exports.searchObjectsByTypeAndOwner = searchObjectsByTypeAndOwner;
const graphql_1 = require("@iota/iota-sdk/graphql");
const _2025_2_1 = require("@iota/iota-sdk/graphql/schemas/2025.2");
/**
 * Returns all owned object IDs matching a specific Move type.
 * Paginates through the full owned-objects list for the owner (RPC).
 */
async function getObjectIdsByType(client, owner, targetType) {
    const found = [];
    let cursor = null;
    for (;;) {
        const page = await client.getOwnedObjects({
            owner,
            cursor,
            options: {
                showType: true,
                showContent: true, // fallback if .type is missing
            },
        });
        const items = page?.data ?? [];
        for (const item of items) {
            const objId = item.data?.objectId;
            if (!objId)
                continue;
            // Fast path
            if (item.data?.type === targetType) {
                found.push(objId);
                continue;
            }
            // Fallback
            const content = item.data?.content;
            if (content?.type === targetType) {
                found.push(objId);
            }
        }
        if (!page?.hasNextPage || !page.nextCursor)
            break;
        cursor = page.nextCursor;
    }
    return found;
}
/**
 * Fetches a single object by id (RPC).
 */
async function getObject(client, id) {
    if (!id)
        return null;
    const { data } = await client.getObject({
        id,
        options: {
            showType: true,
            showOwner: false,
            showPreviousTransaction: false,
            showDisplay: true,
            showContent: true,
            showBcs: true,
            showStorageRebate: false,
        },
    });
    return data ?? null;
}
/**
 * Searches Move objects by type AND owner using GraphQL endpoint.
 * Paginates until completion.
 */
async function searchObjectsByTypeAndOwner(graphqlProvider, objectType, owner) {
    const gqlClient = new graphql_1.IotaGraphQLClient({ url: graphqlProvider });
    const query = (0, _2025_2_1.graphql)(`
    query ObjectsByTypeAndOwner($type: String!, $after: String, $owner: IotaAddress) {
      objects(filter: { type: $type, owner: $owner }, first: 50, after: $after) {
        edges {
          node {
            address
            asMoveObject {
              contents {
                type {
                  repr
                }
                data
              }
            }
          }
        }
        pageInfo {
          hasNextPage
          endCursor
        }
      }
    }
  `);
    const edges = [];
    let after = null;
    try {
        for (;;) {
            const res = await gqlClient.query({
                query,
                variables: { type: objectType, after, owner },
            });
            const page = res?.data?.objects;
            if (!page?.edges?.length)
                break;
            edges.push(...page.edges);
            if (!page.pageInfo.hasNextPage || !page.pageInfo.endCursor)
                break;
            after = page.pageInfo.endCursor;
        }
    }
    catch {
        return [];
    }
    return edges;
}
//# sourceMappingURL=getObjects.js.map