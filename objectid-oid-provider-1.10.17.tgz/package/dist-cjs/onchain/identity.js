"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
let _modP = null;
async function getIdentityMod() {
    if (_modP)
        return _modP;
    _modP = Promise.resolve().then(() => require("@iota/identity-wasm/web"));
    return _modP;
}
//# sourceMappingURL=identity.js.map