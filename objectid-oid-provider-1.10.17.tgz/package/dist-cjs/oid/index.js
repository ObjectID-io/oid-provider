"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createOid = createOid;
const client_1 = require("@iota/iota-sdk/client");
const api_1 = require("../api");
const config_1 = require("../onchain/config");
const getObjects_1 = require("../onchain/getObjects");
const getObject_1 = require("../utils/getObject");
const caps_1 = require("./caps");
const credit_1 = require("./credit");
const graphql_1 = require("./graphql");
const ownedObjects_1 = require("./ownedObjects");
function notInitialized() {
    throw new Error("not initialized");
}
/** Loose network normalization (for selecting a chain to READ public config from). */
function normalizeNetworkLoose(network) {
    const n = String(network ?? "")
        .toLowerCase()
        .trim();
    if (n === "mainnet" || n === "iota")
        return "mainnet";
    return "testnet";
}
/** Strict network read (for setting session network from config JSON). */
function readNetworkFromConfigJson(cfg) {
    const n = String(cfg?.network ?? "")
        .toLowerCase()
        .trim();
    if (n === "mainnet" || n === "iota")
        return "mainnet";
    if (n === "testnet")
        return "testnet";
    throw new Error("configJSON.network must be 'testnet' or 'mainnet'");
}
function tryReadNetworkFromConfigJson(cfg) {
    try {
        return readNetworkFromConfigJson(cfg);
    }
    catch {
        return null;
    }
}
function extractOfficialPackages(json) {
    const raw = json?.officialPackages ?? json?.official_packages ?? json?.official_packages_ids ?? [];
    const arr = Array.isArray(raw) ? raw : [];
    const out = arr.map((x) => (0, caps_1.normalizeHex)(String(x ?? "").trim())).filter((x) => !!x);
    return Array.from(new Set(out));
}
function createOid() {
    let api = null;
    let s = null;
    // ---- NEW: connect-in-progress guard (non-breaking) ----
    // If connect() is running, allow tx calls to wait instead of throwing "not initialized".
    let initP = null;
    const WAITABLE_PROPS = new Set(["create_object", "create_document", "create_event"]);
    // Credit change listeners
    const creditListeners = new Set();
    const emitCreditChanged = (r) => {
        for (const cb of creditListeners) {
            try {
                cb(r);
            }
            catch {
                /* ignore */
            }
        }
    };
    const ensureSession = () => {
        if (!api || !s || !s.initialized)
            notInitialized();
        return { api, s };
    };
    const loadDefaultPublicConfigJson = async (network) => {
        const net = normalizeNetworkLoose(network ?? "testnet");
        const loaded = await (0, config_1.loadPublicConfig)(net);
        return { net, loaded, json: (loaded.json ?? {}) };
    };
    const officialPackages = async (network) => {
        const { json } = await loadDefaultPublicConfigJson(network);
        return extractOfficialPackages(json);
    };
    // ---- helpers: credit token type + refresh ----
    const getCreditTypeArgFromCfg = (cfgAny) => {
        const pkg = (0, caps_1.normalizeHex)(String(cfgAny?.OIDcreditPackage ?? cfgAny?.oidCreditPackage ?? "").trim());
        if (!pkg)
            throw new Error("Missing OIDcreditPackage in config JSON");
        return `${pkg}::oid_credit::OID_CREDIT`;
    };
    const getCreditTokenStructTypeFromCfg = (cfgAny) => {
        const creditTypeArg = getCreditTypeArgFromCfg(cfgAny);
        return `0x2::token::Token<${creditTypeArg}>`;
    };
    const refreshSessionCreditTokens = async (client, cfgAny) => {
        if (!s?.initialized)
            return [];
        const creditTokenType = getCreditTokenStructTypeFromCfg(cfgAny);
        const tokens = await (0, ownedObjects_1.getOwnedObjectIdsByType)(client, s.address, creditTokenType);
        s.creditTokens = tokens;
        if (!s.activeCreditToken || !tokens.includes(s.activeCreditToken)) {
            s.activeCreditToken = tokens[0];
        }
        return tokens;
    };
    const applyConfigJsonForSession = async (did, seed, seedPath, network, cfgJson, configObjectId, publicConfig) => {
        const merged = {
            ...cfgJson,
            network,
            seed,
            seedPath,
        };
        api = (0, api_1.createObjectIdApi)(merged);
        api.onTxExecuted = (r) => emitCreditChanged(r);
        const env = await api.env();
        const client = env.client;
        const address = env.sender;
        const graphqlProvider = env.graphqlProvider;
        const cfgAny = cfgJson;
        const iotaIdentityPackage = (0, caps_1.normalizeHex)(String(cfgAny.IOTAidentityPackage ?? ""));
        const oidIdentityPackage = (0, caps_1.normalizeHex)(String(cfgAny.OIDidentityPackage ?? ""));
        if (!iotaIdentityPackage)
            throw new Error("Missing IOTAidentityPackage in config JSON");
        if (!oidIdentityPackage)
            throw new Error("Missing OIDidentityPackage in config JSON");
        const identityCapType = `${iotaIdentityPackage}::controller::ControllerCap`;
        const oidCapType = `${oidIdentityPackage}::oid_identity::ControllerCap`;
        const identityCapIds = await (0, ownedObjects_1.getOwnedObjectIdsByType)(client, address, identityCapType);
        const identityControllerCap = await (0, caps_1.pickCapMatchingDid)(client, identityCapIds, did);
        if (!identityControllerCap)
            throw new Error("IOTA Identity ControllerCap not found for the provided DID");
        // OID Identity ControllerCap is OPTIONAL.
        const didId = (() => {
            const ss = String(did ?? "").trim();
            const last = ss.split(":").pop() ?? "";
            const ok = last && /^(0x)?[0-9a-fA-F]+$/.test(last);
            return ok ? (0, caps_1.normalizeHex)(last) : "";
        })();
        let oidControllerCap;
        let identityIsLinked = false;
        // RPC-only: scan owned ControllerCap objects and match fields.controller_of == didId
        if (didId) {
            try {
                const oidCapIds = await (0, getObjects_1.getObjectIdsByType)(client, address, oidCapType);
                const matches = [];
                for (const id of oidCapIds) {
                    const obj = await (0, getObject_1.getObject)(client, id);
                    if (!obj)
                        continue;
                    const fields = obj?.content?.fields ??
                        obj?.content?.data?.fields ??
                        obj?.data?.content?.fields ??
                        obj?.data?.content?.data?.fields ??
                        {};
                    const controllerOf = (0, caps_1.normalizeHex)(String(fields?.controller_of ?? ""));
                    if (!controllerOf || controllerOf !== didId)
                        continue;
                    const vRaw = obj?.version;
                    let v = 0n;
                    try {
                        if (typeof vRaw === "string" && vRaw)
                            v = BigInt(vRaw);
                        else if (typeof vRaw === "number")
                            v = BigInt(vRaw);
                    }
                    catch {
                        v = 0n;
                    }
                    matches.push({ id, version: v });
                }
                if (matches.length > 0) {
                    matches.sort((a, b) => (a.version === b.version ? a.id.localeCompare(b.id) : a.version > b.version ? -1 : 1));
                    oidControllerCap = matches[0].id;
                    identityIsLinked = true;
                }
            }
            catch {
                // ok: remains false
            }
        }
        const creditTokenType = getCreditTokenStructTypeFromCfg(cfgAny);
        const creditTokens = await (0, ownedObjects_1.getOwnedObjectIdsByType)(client, address, creditTokenType);
        s = {
            initialized: true,
            network,
            did,
            seed,
            seedPath,
            address,
            graphqlProvider,
            configJson: cfgJson,
            configObjectId,
            publicConfig,
            identityControllerCap,
            oidControllerCap,
            identityIsLinked,
            creditTokens,
            activeCreditToken: creditTokens[0],
        };
    };
    // --- API: setSession(configJSON) ---
    const setSession = async (configJSON) => {
        // NEW: if connect is running, wait it
        if (initP)
            await initP;
        const { s: cur } = ensureSession();
        if (!configJSON || typeof configJSON !== "object" || Array.isArray(configJSON)) {
            throw new Error("configJSON must be an object");
        }
        const net = readNetworkFromConfigJson(configJSON);
        await applyConfigJsonForSession(cur.did, cur.seed, cur.seedPath, net, configJSON);
    };
    // --- Read-only session.config(network?) with requested semantics ---
    const sessionConfig = async (network) => {
        const requestedNet = normalizeNetworkLoose(network ?? s?.network ?? "testnet");
        // session attiva:
        // - config() o config(session.network) => config di sessione
        // - config(other) => default pubblico dell'altra rete
        if (s?.initialized) {
            const sessionNet = normalizeNetworkLoose(String(s.network ?? "testnet"));
            if (!network || requestedNet === sessionNet)
                return s.configJson;
            const { json } = await loadDefaultPublicConfigJson(requestedNet);
            return json;
        }
        // no session => default pubblico della rete richiesta
        const { json } = await loadDefaultPublicConfigJson(requestedNet);
        return json;
    };
    const connect = async (p) => {
        // NEW: serialize connect calls; if a connect is already in progress, wait it
        if (initP)
            await initP;
        const task = (async () => {
            const did = String(p?.did ?? "").trim();
            const seed = String(p?.seed ?? "").trim();
            const seedPath = String(p?.seedPath ?? "").trim() || undefined;
            if (!did)
                throw new Error("DID is required.");
            if (!seed)
                throw new Error("Seed is required.");
            // Bootstrapping: read pinned public config from the selected chain.
            const { loaded, json } = await loadDefaultPublicConfigJson(p.network);
            // Session network is derived from json.network (strict if present; fallback to the chain used to read public config).
            const net = tryReadNetworkFromConfigJson(json) ?? normalizeNetworkLoose(p.network);
            await applyConfigJsonForSession(did, seed, seedPath, net, json, loaded.objectId, loaded);
        })();
        initP = task;
        try {
            await task;
        }
        finally {
            if (initP === task)
                initP = null;
        }
    };
    const disconnect = () => {
        api = null;
        s = null;
        initP = null; // NEW
    };
    const sessionObj = {
        get network() {
            return ensureSession().s.network;
        },
        get did() {
            return ensureSession().s.did;
        },
        get address() {
            return ensureSession().s.address;
        },
        get identityIsLinked() {
            return ensureSession().s.identityIsLinked;
        },
        get oidControllerCap() {
            return ensureSession().s.oidControllerCap;
        },
        get identityControllerCap() {
            return ensureSession().s.identityControllerCap;
        },
        get creditTokens() {
            return ensureSession().s.creditTokens;
        },
        creditToken(id) {
            const { s } = ensureSession();
            if (id === undefined)
                return s.activeCreditToken;
            const t = id.trim();
            if (!t)
                throw new Error("creditToken id is required");
            if (!s.creditTokens.includes(t))
                throw new Error("creditToken not owned by the current address");
            s.activeCreditToken = t;
            return s.activeCreditToken;
        },
        onCreditChanged(cb) {
            creditListeners.add(cb);
            return () => creditListeners.delete(cb);
        },
        async credit() {
            const { api, s } = ensureSession();
            const tokenId = s.activeCreditToken;
            if (!tokenId)
                return null;
            const env = await api.env();
            const obj = await (0, getObject_1.getObject)(env.client, tokenId);
            return (0, credit_1.extractBalance)(obj ?? null);
        },
        config: sessionConfig,
        raw() {
            return ensureSession().s;
        },
    };
    const base = {
        connect,
        disconnect,
        setSession,
        async faucet() {
            const { s } = ensureSession();
            const net = String(s.network).toLowerCase().trim();
            if (net !== "testnet")
                throw new Error("faucet is available only for an active testnet session");
            const cfg = await sessionConfig();
            const faucetURL = String(cfg.faucetURL).trim();
            if (!faucetURL)
                throw new Error("Missing faucetURL in config JSON");
            const cfgAny = cfg;
            const OIDcreditPackage = (0, caps_1.normalizeHex)(String(cfgAny.OIDcreditPackage ?? "").trim());
            if (!OIDcreditPackage)
                throw new Error("Missing OIDcreditPackage in config JSON");
            const address = String(s.address).trim();
            const response = await fetch(faucetURL, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ packageId: OIDcreditPackage, address }),
            });
            try {
                await response.json();
            }
            catch {
                /* ignore */
            }
            if (!response.ok) {
                return "❌ Failed to request free credits. You own credit!";
            }
            else {
                return "✅ 20 free credits have been minted to your address!";
            }
        },
        officialPackages,
        get policyToken() {
            const { api } = ensureSession();
            return api.env().then((e) => e.policy);
        },
        session: sessionObj,
        // uninitialized-safe methods
        async getObject(id, network) {
            const client = new client_1.IotaClient({ url: (0, client_1.getFullnodeUrl)(network) });
            const obj = await (0, getObject_1.getObject)(client, id);
            return obj ?? null;
        },
        async getObjectsByType(type, network) {
            const cfg = await sessionConfig(network);
            const graphqlProvider = String(cfg?.graphqlProvider ?? "").trim();
            if (!graphqlProvider)
                throw new Error("graphqlProvider not found in public config");
            return await (0, graphql_1.graphqlAllByType)(graphqlProvider, type);
        },
        async getObjectsByTypeAndOwner(type, owner, network) {
            const cfg = await sessionConfig(network);
            const graphqlProvider = String(cfg?.graphqlProvider ?? "").trim();
            if (!graphqlProvider)
                throw new Error("graphqlProvider not found in public config");
            return await (0, graphql_1.graphqlAllByTypeAndOwner)(graphqlProvider, type, owner);
        },
    };
    return new Proxy(base, {
        get(_target, prop) {
            if (prop in base)
                return base[prop];
            if (prop === "toJSON")
                return () => ({
                    connected: !!s?.initialized,
                    network: s?.network,
                    address: s?.address,
                });
            // If connect() is in progress, let known tx calls wait (non-breaking).
            if (typeof prop === "string" && initP && WAITABLE_PROPS.has(prop)) {
                return async (params) => {
                    await initP; // propagate connect error if it failed
                    const { api, s } = ensureSession();
                    const v = api[prop];
                    if (typeof v !== "function")
                        throw new Error(`Method '${prop}' not available on ObjectIdApi`);
                    if ((prop === "create_object" || prop === "create_document") && !s.identityIsLinked) {
                        throw new Error("function not allowed");
                    }
                    return v.call(api, params);
                };
            }
            // If api exists, return the api method/value.
            // NOTE: keep original behavior for create_object/create_document gating.
            if (api && api[prop] !== undefined) {
                const v = api[prop];
                if (typeof v === "function" && (prop === "create_object" || prop === "create_document")) {
                    return (params) => {
                        const { s } = ensureSession();
                        if (!s.identityIsLinked)
                            throw new Error("function not allowed");
                        return v.call(api, params);
                    };
                }
                return typeof v === "function" ? v.bind(api) : v;
            }
            // ---- NEW: avoid stale function references ----
            // Previously: return () => notInitialized();
            // Now: return a function that re-checks current api at call time.
            if (typeof prop === "string") {
                return (params) => {
                    if (api && api[prop] !== undefined) {
                        const v = api[prop];
                        if (typeof v !== "function")
                            return v;
                        // preserve gating semantics
                        if ((prop === "create_object" || prop === "create_document") && s?.initialized) {
                            if (!s.identityIsLinked)
                                throw new Error("function not allowed");
                        }
                        return v.call(api, params);
                    }
                    return notInitialized();
                };
            }
            return () => notInitialized();
        },
    });
}
//# sourceMappingURL=index.js.map