"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.graphqlAllByType = graphqlAllByType;
exports.graphqlAllByTypeAndOwner = graphqlAllByTypeAndOwner;
async function fetchEdges(graphqlProvider, query, variables) {
    const resp = await fetch(graphqlProvider, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ query, variables }),
    });
    const json = (await resp.json().catch(() => null));
    if (!resp.ok)
        throw Object.assign(new Error(`GraphQL HTTP ${resp.status}`), { status: resp.status, json });
    if (json?.errors)
        throw Object.assign(new Error("GraphQL errors"), { errors: json.errors });
    const page = json?.data?.objects;
    const pageEdges = page?.edges ?? [];
    const hasNext = !!page?.pageInfo?.hasNextPage;
    const endCursor = (page?.pageInfo?.endCursor ?? null);
    return { edges: pageEdges, endCursor, hasNext };
}
async function graphqlAll(graphqlProvider, query, makeVariables) {
    const edges = [];
    let after = null;
    for (;;) {
        const page = await fetchEdges(graphqlProvider, query, makeVariables(after));
        if (page.edges.length)
            edges.push(...page.edges);
        if (!page.hasNext || !page.endCursor)
            break;
        after = page.endCursor;
    }
    return edges;
}
async function graphqlAllByType(graphqlProvider, type) {
    const query = `
    query ($type: String!, $after: String) {
      objects(filter: { type: $type }, first: 50, after: $after) {
        edges {
          cursor
          node {
            address
            asMoveObject {
              contents { type { repr } data }
            }
          }
        }
        pageInfo { hasNextPage endCursor }
      }
    }
  `;
    return graphqlAll(graphqlProvider, query, (after) => ({ type, after }));
}
async function graphqlAllByTypeAndOwner(graphqlProvider, type, owner) {
    const query = `
    query ($type: String!, $after: String, $owner: IotaAddress) {
      objects(filter: { type: $type, owner: $owner }, first: 50, after: $after) {
        edges {
          cursor
          node {
            address
            asMoveObject {
              contents { type { repr } data }
            }
          }
        }
        pageInfo { hasNextPage endCursor }
      }
    }
  `;
    return graphqlAll(graphqlProvider, query, (after) => ({ type, after, owner }));
}
//# sourceMappingURL=graphql.js.map