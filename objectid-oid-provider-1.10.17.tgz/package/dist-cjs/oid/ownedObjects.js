"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getOwnedObjectIdsByType = getOwnedObjectIdsByType;
/**
 * Fetch all owned objectIds for a specific Move type.
 *
 * Uses the RPC ownedObjects listing and matches either the top-level `data.type`
 * or `data.content.type`.
 */
async function getOwnedObjectIdsByType(client, owner, targetType) {
    const found = [];
    let cursor = null;
    for (;;) {
        const page = await client.getOwnedObjects({
            owner,
            cursor,
            options: { showType: true, showContent: true },
        });
        const items = page?.data ?? [];
        for (const item of items) {
            const objId = item.data?.objectId;
            if (!objId)
                continue;
            const directType = item.data?.type;
            if (directType && directType === targetType) {
                found.push(objId);
                continue;
            }
            const content = item.data?.content;
            const contentType = content?.type;
            if (contentType && contentType === targetType) {
                found.push(objId);
            }
        }
        if (!page?.hasNextPage || !page.nextCursor)
            break;
        cursor = page.nextCursor;
    }
    return found;
}
//# sourceMappingURL=ownedObjects.js.map