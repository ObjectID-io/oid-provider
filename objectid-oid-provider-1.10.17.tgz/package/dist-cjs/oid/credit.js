"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.extractBalance = extractBalance;
/**
 * Best-effort extraction of a token balance from a Move object.
 * Handles common shapes and falls back to a deep scan for the first numeric string.
 */
function extractBalance(obj) {
    if (!obj)
        return null;
    const fields = obj?.content?.fields;
    if (!fields)
        return null;
    // common shapes:
    // balance: "123"
    // balance: { fields: { value: "123" } }
    const b = fields.balance;
    if (typeof b === "string")
        return b;
    if (typeof b === "number")
        return String(b);
    if (b && typeof b === "object") {
        const v = b.fields?.value ?? b.value;
        if (typeof v === "string")
            return v;
        if (typeof v === "number")
            return String(v);
    }
    // fallback: deep search for first numeric-like string
    const stack = [fields];
    const seen = new Set();
    while (stack.length) {
        const v = stack.pop();
        if (v == null)
            continue;
        if (typeof v === "string" && /^[0-9]+$/.test(v))
            return v;
        if (typeof v !== "object")
            continue;
        if (seen.has(v))
            continue;
        seen.add(v);
        if (Array.isArray(v))
            stack.push(...v);
        else
            for (const k of Object.keys(v))
                stack.push(v[k]);
    }
    return null;
}
//# sourceMappingURL=credit.js.map