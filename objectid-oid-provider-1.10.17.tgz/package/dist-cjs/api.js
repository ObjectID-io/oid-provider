"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createObjectIdApi = createObjectIdApi;
const env_1 = require("./env");
const graphql_1 = require("./utils/graphql");
const getObject_1 = require("./utils/getObject");
const methods = require("./methods");
function normalizeGasBudget(value) {
    const normalized = typeof value === "string"
        ? value.trim().replace(/[_\s,]/g, "")
        : value;
    const n = typeof normalized === "number" ? normalized : Number(normalized);
    if (Number.isFinite(n) && n > 0)
        return Math.floor(n);
    return 10_000_000;
}
function createObjectIdApi(cfg) {
    let _envPromise = null;
    const gasBudget = normalizeGasBudget(cfg.gasBudget);
    const useGasStation = !!cfg.useGasStation;
    const gasStation = cfg.gasStation;
    async function env() {
        if (!_envPromise)
            _envPromise = (0, env_1.resolveEnv)(cfg);
        return _envPromise;
    }
    const apiRef = {
        env,
        gasBudget,
        useGasStation,
        gasStation,
        async get_object({ objectId }) {
            const e = await env();
            return (0, getObject_1.getObject)(e.client, objectId);
        },
        async get_objects({ after = null }) {
            const e = await env();
            return (0, graphql_1.searchObjectsByType)(e.OIDobjectType, after, e.graphqlProvider);
        },
        document_did_string({ id }) {
            const raw = String(id || "").trim();
            const hex = raw.startsWith("0x") ? raw.slice(2) : raw;
            return "did:iota:0x" + hex.toLowerCase();
        },
    };
    // Bind ALL tx methods from ./methods/* so they keep their (typed) params in IntelliSense.
    for (const k of Object.keys(methods)) {
        // Runtime binding only; typing is provided by the ObjectIdApi & TxMethods types above.
        apiRef[k] = (params) => methods[k](apiRef, params);
    }
    return apiRef;
}
//# sourceMappingURL=api.js.map