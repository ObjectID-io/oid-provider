"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.create_component = create_component;
exports.delete_component = delete_component;
const transactions_1 = require("@iota/iota-sdk/transactions");
const tx_1 = require("../utils/tx");
async function create_component(api, params) {
    const { creditToken, controllerCap, object, component_id, description } = params;
    const env = await api.env();
    const gasBudget = api.gasBudget;
    const tx = new transactions_1.Transaction();
    const moveFunction = env.packageID + "::oid_object::create_component";
    tx.moveCall({
        arguments: [
            tx.object(creditToken),
            tx.object(env.policy),
            tx.object(controllerCap),
            tx.object(object),
            tx.pure.address(component_id),
            tx.pure.string(String(description ?? "")),
        ],
        target: moveFunction,
    });
    tx.setGasBudget(gasBudget);
    tx.setSender(env.sender);
    const r = await (0, tx_1.signAndExecute)(env.client, env.keyPair, tx, {
        network: env.network,
        gasBudget,
        useGasStation: api.useGasStation,
        gasStation: api.gasStation,
        onExecuted: api.onTxExecuted,
    });
    return r;
}
async function delete_component(api, params) {
    const { creditToken, controllerCap, object, component } = params;
    const env = await api.env();
    const gasBudget = api.gasBudget;
    const tx = new transactions_1.Transaction();
    const moveFunction = env.packageID + "::oid_object::delete_component";
    tx.moveCall({
        arguments: [
            tx.object(creditToken),
            tx.object(env.policy),
            tx.object(controllerCap),
            tx.object(object),
            tx.object(component),
        ],
        target: moveFunction,
    });
    tx.setGasBudget(gasBudget);
    tx.setSender(env.sender);
    const r = await (0, tx_1.signAndExecute)(env.client, env.keyPair, tx, {
        network: env.network,
        gasBudget,
        useGasStation: api.useGasStation,
        gasStation: api.gasStation,
        onExecuted: api.onTxExecuted,
    });
    return r;
}
//# sourceMappingURL=component.js.map