"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.add_approver_did = add_approver_did;
exports.add_document_credit = add_document_credit;
exports.add_editors_did = add_editors_did;
exports.append_change_log = append_change_log;
exports.approve_document = approve_document;
exports.create_document = create_document;
exports.delete_document = delete_document;
exports.remove_approver_did = remove_approver_did;
exports.remove_editors_did = remove_editors_did;
exports.update_document_mutable_metadata = update_document_mutable_metadata;
exports.update_document_owner_did = update_document_owner_did;
exports.update_document_status = update_document_status;
exports.update_document_url_hash = update_document_url_hash;
exports.update_publisher_did = update_publisher_did;
const transactions_1 = require("@iota/iota-sdk/transactions");
const env_1 = require("../env");
const tx_1 = require("../utils/tx");
const url_1 = require("../utils/url");
async function add_approver_did(api, params) {
    const { controllerCap, document, new_approver_did } = params;
    const env = await api.env();
    const gasBudget = api.gasBudget;
    const tx = new transactions_1.Transaction();
    const moveFunction = env.documentPackageID + "::oid_document::add_approver_did";
    tx.moveCall({
        arguments: [tx.object(controllerCap), tx.object(document), tx.pure.string(String(new_approver_did ?? ""))],
        target: moveFunction,
    });
    tx.setGasBudget(gasBudget);
    tx.setSender(env.sender);
    const r = await (0, tx_1.signAndExecute)(env.client, env.keyPair, tx, {
        network: env.network,
        gasBudget,
        useGasStation: api.useGasStation,
        gasStation: api.gasStation,
        onExecuted: api.onTxExecuted,
    });
    return r;
}
async function add_document_credit(api, params) {
    const { creditToken, document } = params;
    const env = await api.env();
    const gasBudget = api.gasBudget;
    const tx = new transactions_1.Transaction();
    const moveFunction = env.documentPackageID + "::oid_document::add_document_credit";
    tx.moveCall({
        arguments: [tx.object(creditToken), tx.object(env.policy), tx.object(document)],
        target: moveFunction,
    });
    tx.setGasBudget(gasBudget);
    tx.setSender(env.sender);
    const r = await (0, tx_1.signAndExecute)(env.client, env.keyPair, tx, {
        network: env.network,
        gasBudget,
        useGasStation: api.useGasStation,
        gasStation: api.gasStation,
        onExecuted: api.onTxExecuted,
    });
    return r;
}
async function add_editors_did(api, params) {
    const { controllerCap, document, new_editor_did } = params;
    const env = await api.env();
    const gasBudget = api.gasBudget;
    const tx = new transactions_1.Transaction();
    const moveFunction = env.documentPackageID + "::oid_document::add_editors_did";
    tx.moveCall({
        arguments: [tx.object(controllerCap), tx.object(document), tx.pure.string(String(new_editor_did ?? ""))],
        target: moveFunction,
    });
    tx.setGasBudget(gasBudget);
    tx.setSender(env.sender);
    const r = await (0, tx_1.signAndExecute)(env.client, env.keyPair, tx, {
        network: env.network,
        gasBudget,
        useGasStation: api.useGasStation,
        gasStation: api.gasStation,
        onExecuted: api.onTxExecuted,
    });
    return r;
}
async function append_change_log(api, params) {
    const { document, actor, op_desc, params: change_params } = params;
    const env = await api.env();
    const gasBudget = api.gasBudget;
    const tx = new transactions_1.Transaction();
    const moveFunction = env.documentPackageID + "::oid_document::append_change_log";
    tx.moveCall({
        arguments: [
            tx.object(document),
            tx.pure.string(String(actor ?? "")),
            tx.pure.string(String(op_desc ?? "")),
            tx.pure.string((0, env_1.asJsonString)(change_params)),
            tx.object("0x6"),
        ],
        target: moveFunction,
    });
    tx.setGasBudget(gasBudget);
    tx.setSender(env.sender);
    const r = await (0, tx_1.signAndExecute)(env.client, env.keyPair, tx, {
        network: env.network,
        gasBudget,
        useGasStation: api.useGasStation,
        gasStation: api.gasStation,
        onExecuted: api.onTxExecuted,
    });
    return r;
}
async function approve_document(api, params) {
    const { controllerCap, document, new_approval_flag } = params;
    const env = await api.env();
    const gasBudget = api.gasBudget;
    const tx = new transactions_1.Transaction();
    const moveFunction = env.documentPackageID + "::oid_document::approve_document";
    tx.moveCall({
        arguments: [
            tx.object(controllerCap),
            tx.object(document),
            tx.pure.u8(Number(new_approval_flag)),
            tx.object("0x6"),
        ],
        target: moveFunction,
    });
    tx.setGasBudget(gasBudget);
    tx.setSender(env.sender);
    const r = await (0, tx_1.signAndExecute)(env.client, env.keyPair, tx, {
        network: env.network,
        gasBudget,
        useGasStation: api.useGasStation,
        gasStation: api.gasStation,
        onExecuted: api.onTxExecuted,
    });
    return r;
}
async function create_document(api, params) {
    const { creditToken, OIDcontrollerCap, document_url, description, immutable_metadata, mutable_metadata } = params;
    const env = await api.env();
    const gasBudget = api.gasBudget;
    const safeDocumentUrl = (0, url_1.ensureTrailingSlashForOriginOnly)(document_url);
    const tx = new transactions_1.Transaction();
    const moveFunction = env.documentPackageID + "::oid_document::create_document";
    tx.moveCall({
        arguments: [
            tx.object(creditToken),
            tx.object(env.policy),
            tx.object(OIDcontrollerCap),
            tx.pure.string(String(safeDocumentUrl ?? "")),
            tx.pure.string(String(description ?? "")),
            tx.pure.string((0, env_1.asJsonString)(immutable_metadata)),
            tx.pure.string((0, env_1.asJsonString)(mutable_metadata)),
            tx.object("0x6"),
        ],
        target: moveFunction,
    });
    tx.setGasBudget(gasBudget);
    tx.setSender(env.sender);
    const r = await (0, tx_1.signAndExecute)(env.client, env.keyPair, tx, {
        network: env.network,
        gasBudget,
        useGasStation: api.useGasStation,
        gasStation: api.gasStation,
        onExecuted: api.onTxExecuted,
    });
    return r;
}
async function delete_document(api, params) {
    const { controllerCap, document } = params;
    const env = await api.env();
    const gasBudget = api.gasBudget;
    const tx = new transactions_1.Transaction();
    const moveFunction = env.documentPackageID + "::oid_document::delete_document";
    tx.moveCall({
        arguments: [tx.object(controllerCap), tx.object(document)],
        target: moveFunction,
    });
    tx.setGasBudget(gasBudget);
    tx.setSender(env.sender);
    const r = await (0, tx_1.signAndExecute)(env.client, env.keyPair, tx, {
        network: env.network,
        gasBudget,
        useGasStation: api.useGasStation,
        gasStation: api.gasStation,
        onExecuted: api.onTxExecuted,
    });
    return r;
}
async function remove_approver_did(api, params) {
    const { controllerCap, document, approver_did } = params;
    const env = await api.env();
    const gasBudget = api.gasBudget;
    const tx = new transactions_1.Transaction();
    const moveFunction = env.documentPackageID + "::oid_document::remove_approver_did";
    tx.moveCall({
        arguments: [tx.object(controllerCap), tx.object(document), tx.pure.string(String(approver_did ?? ""))],
        target: moveFunction,
    });
    tx.setGasBudget(gasBudget);
    tx.setSender(env.sender);
    const r = await (0, tx_1.signAndExecute)(env.client, env.keyPair, tx, {
        network: env.network,
        gasBudget,
        useGasStation: api.useGasStation,
        gasStation: api.gasStation,
        onExecuted: api.onTxExecuted,
    });
    return r;
}
async function remove_editors_did(api, params) {
    const { controllerCap, document, editor_did } = params;
    const env = await api.env();
    const gasBudget = api.gasBudget;
    const tx = new transactions_1.Transaction();
    const moveFunction = env.documentPackageID + "::oid_document::remove_editors_did";
    tx.moveCall({
        arguments: [tx.object(controllerCap), tx.object(document), tx.pure.string(String(editor_did ?? ""))],
        target: moveFunction,
    });
    tx.setGasBudget(gasBudget);
    tx.setSender(env.sender);
    const r = await (0, tx_1.signAndExecute)(env.client, env.keyPair, tx, {
        network: env.network,
        gasBudget,
        useGasStation: api.useGasStation,
        gasStation: api.gasStation,
        onExecuted: api.onTxExecuted,
    });
    return r;
}
async function update_document_mutable_metadata(api, params) {
    const { controllerCap, document, new_mutable_metadata } = params;
    const env = await api.env();
    const gasBudget = api.gasBudget;
    const tx = new transactions_1.Transaction();
    const moveFunction = env.documentPackageID + "::oid_document::update_document_mutable_metadata";
    tx.moveCall({
        arguments: [
            tx.object(controllerCap),
            tx.object(document),
            tx.pure.string((0, env_1.asJsonString)(new_mutable_metadata)),
            tx.object("0x6"),
        ],
        target: moveFunction,
    });
    tx.setGasBudget(gasBudget);
    tx.setSender(env.sender);
    const r = await (0, tx_1.signAndExecute)(env.client, env.keyPair, tx, {
        network: env.network,
        gasBudget,
        useGasStation: api.useGasStation,
        gasStation: api.gasStation,
        onExecuted: api.onTxExecuted,
    });
    return r;
}
async function update_document_owner_did(api, params) {
    const { controllerCap, document, new_owner_did } = params;
    const env = await api.env();
    const gasBudget = api.gasBudget;
    const tx = new transactions_1.Transaction();
    const moveFunction = env.documentPackageID + "::oid_document::update_owner_did";
    tx.moveCall({
        arguments: [tx.object(controllerCap), tx.object(document), tx.pure.string(String(new_owner_did ?? ""))],
        target: moveFunction,
    });
    tx.setGasBudget(gasBudget);
    tx.setSender(env.sender);
    const r = await (0, tx_1.signAndExecute)(env.client, env.keyPair, tx, {
        network: env.network,
        gasBudget,
        useGasStation: api.useGasStation,
        gasStation: api.gasStation,
        onExecuted: api.onTxExecuted,
    });
    return r;
}
async function update_document_status(api, params) {
    const { controllerCap, document, new_status } = params;
    const env = await api.env();
    const gasBudget = api.gasBudget;
    const tx = new transactions_1.Transaction();
    const moveFunction = env.documentPackageID + "::oid_document::update_document_status";
    tx.moveCall({
        arguments: [tx.object(controllerCap), tx.object(document), tx.pure.u8(Number(new_status)), tx.object("0x6")],
        target: moveFunction,
    });
    tx.setGasBudget(gasBudget);
    tx.setSender(env.sender);
    const r = await (0, tx_1.signAndExecute)(env.client, env.keyPair, tx, {
        network: env.network,
        gasBudget,
        useGasStation: api.useGasStation,
        gasStation: api.gasStation,
        onExecuted: api.onTxExecuted,
    });
    return r;
}
async function update_document_url_hash(api, params) {
    const { controllerCap, document, new_hash, new_document_url } = params;
    const env = await api.env();
    const gasBudget = api.gasBudget;
    const safeUrl = (0, url_1.ensureTrailingSlashForOriginOnly)(new_document_url);
    const tx = new transactions_1.Transaction();
    const moveFunction = env.documentPackageID + "::oid_document::update_document_url_hash";
    tx.moveCall({
        arguments: [
            tx.object(controllerCap),
            tx.object(document),
            tx.pure.string(String(new_hash ?? "")),
            tx.pure.string(String(safeUrl ?? "")),
            tx.object("0x6"),
        ],
        target: moveFunction,
    });
    tx.setGasBudget(gasBudget);
    tx.setSender(env.sender);
    const r = await (0, tx_1.signAndExecute)(env.client, env.keyPair, tx, {
        network: env.network,
        gasBudget,
        useGasStation: api.useGasStation,
        gasStation: api.gasStation,
        onExecuted: api.onTxExecuted,
    });
    return r;
}
async function update_publisher_did(api, params) {
    const { controllerCap, document, new_publisher_did } = params;
    const env = await api.env();
    const gasBudget = api.gasBudget;
    const tx = new transactions_1.Transaction();
    const moveFunction = env.documentPackageID + "::oid_document::update_publisher_did";
    tx.moveCall({
        arguments: [tx.object(controllerCap), tx.object(document), tx.pure.string(String(new_publisher_did ?? ""))],
        target: moveFunction,
    });
    tx.setGasBudget(gasBudget);
    tx.setSender(env.sender);
    const r = await (0, tx_1.signAndExecute)(env.client, env.keyPair, tx, {
        network: env.network,
        gasBudget,
        useGasStation: api.useGasStation,
        gasStation: api.gasStation,
        onExecuted: api.onTxExecuted,
    });
    return r;
}
//# sourceMappingURL=document.js.map