"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.create_counter = create_counter;
exports.delete_counter = delete_counter;
exports.counter_set_value = counter_set_value;
exports.counter_stepdown = counter_stepdown;
exports.counter_stepup = counter_stepup;
const transactions_1 = require("@iota/iota-sdk/transactions");
const env_1 = require("../env");
const tx_1 = require("../utils/tx");
async function create_counter(api, params) {
    const { creditToken, controllerCap, object, value, unit, step, immutable_metadata, mutable_metadata } = params;
    const env = await api.env();
    const gasBudget = api.gasBudget;
    const tx = new transactions_1.Transaction();
    const moveFunction = env.packageID + "::oid_object::create_counter";
    tx.moveCall({
        arguments: [
            tx.object(creditToken),
            tx.object(env.policy),
            tx.object(controllerCap),
            tx.pure.address(object),
            tx.pure.u64(value),
            tx.pure.string(String(unit ?? "")),
            tx.pure.u64(step),
            tx.pure.string((0, env_1.asJsonString)(immutable_metadata)),
            tx.pure.string((0, env_1.asJsonString)(mutable_metadata)),
        ],
        target: moveFunction,
    });
    tx.setGasBudget(gasBudget);
    tx.setSender(env.sender);
    const r = await (0, tx_1.signAndExecute)(env.client, env.keyPair, tx, {
        network: env.network,
        gasBudget,
        useGasStation: api.useGasStation,
        gasStation: api.gasStation,
        onExecuted: api.onTxExecuted,
    });
    return r;
}
async function delete_counter(api, params) {
    const { creditToken, controllerCap, object, counter } = params;
    const env = await api.env();
    const gasBudget = api.gasBudget;
    const tx = new transactions_1.Transaction();
    const moveFunction = env.packageID + "::oid_object::delete_counter";
    tx.moveCall({
        arguments: [
            tx.object(creditToken),
            tx.object(env.policy),
            tx.object(controllerCap),
            tx.object(object),
            tx.object(counter),
        ],
        target: moveFunction,
    });
    tx.setGasBudget(gasBudget);
    tx.setSender(env.sender);
    const r = await (0, tx_1.signAndExecute)(env.client, env.keyPair, tx, {
        network: env.network,
        gasBudget,
        useGasStation: api.useGasStation,
        gasStation: api.gasStation,
        onExecuted: api.onTxExecuted,
    });
    return r;
}
async function counter_set_value(api, params) {
    const { creditToken, controllerCap, objectId, counter, new_value } = params;
    const env = await api.env();
    const gasBudget = api.gasBudget;
    const tx = new transactions_1.Transaction();
    const moveFunction = env.packageID + "::oid_object::counter_set_value";
    tx.moveCall({
        arguments: [
            tx.object(creditToken),
            tx.object(env.policy),
            tx.object(controllerCap),
            tx.object(objectId),
            tx.object(counter),
            tx.pure.u64(new_value),
        ],
        target: moveFunction,
    });
    tx.setGasBudget(gasBudget);
    tx.setSender(env.sender);
    const r = await (0, tx_1.signAndExecute)(env.client, env.keyPair, tx, {
        network: env.network,
        gasBudget,
        useGasStation: api.useGasStation,
        gasStation: api.gasStation,
        onExecuted: api.onTxExecuted,
    });
    return r;
}
async function counter_stepdown(api, params) {
    const { creditToken, controllerCap, objectId, counter } = params;
    const env = await api.env();
    const gasBudget = api.gasBudget;
    const tx = new transactions_1.Transaction();
    const moveFunction = env.packageID + "::oid_object::counter_stepdown";
    tx.moveCall({
        arguments: [
            tx.object(creditToken),
            tx.object(env.policy),
            tx.object(controllerCap),
            tx.object(objectId),
            tx.object(counter),
        ],
        target: moveFunction,
    });
    tx.setGasBudget(gasBudget);
    tx.setSender(env.sender);
    const r = await (0, tx_1.signAndExecute)(env.client, env.keyPair, tx, {
        network: env.network,
        gasBudget,
        useGasStation: api.useGasStation,
        gasStation: api.gasStation,
        onExecuted: api.onTxExecuted,
    });
    return r;
}
async function counter_stepup(api, params) {
    const { creditToken, controllerCap, object, counter } = params;
    const env = await api.env();
    const gasBudget = api.gasBudget;
    const tx = new transactions_1.Transaction();
    const moveFunction = env.packageID + "::oid_object::counter_stepup";
    tx.moveCall({
        arguments: [
            tx.object(creditToken),
            tx.object(env.policy),
            tx.object(controllerCap),
            tx.object(object),
            tx.object(counter),
        ],
        target: moveFunction,
    });
    tx.setGasBudget(gasBudget);
    tx.setSender(env.sender);
    const r = await (0, tx_1.signAndExecute)(env.client, env.keyPair, tx, {
        network: env.network,
        gasBudget,
        useGasStation: api.useGasStation,
        gasStation: api.gasStation,
        onExecuted: api.onTxExecuted,
    });
    return r;
}
//# sourceMappingURL=counter.js.map