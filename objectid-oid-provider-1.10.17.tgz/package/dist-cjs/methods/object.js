"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.create_object = create_object;
exports.delete_object = delete_object;
exports.update_agent_did = update_agent_did;
exports.update_geo_location = update_geo_location;
exports.update_geolocation = update_geolocation;
exports.update_object = update_object;
exports.update_object_did = update_object_did;
exports.update_object_mutable_metadata = update_object_mutable_metadata;
exports.update_op_code = update_op_code;
exports.update_owner_did = update_owner_did;
const transactions_1 = require("@iota/iota-sdk/transactions");
const utils_1 = require("@iota/iota-sdk/utils");
const env_1 = require("../env");
const tx_1 = require("../utils/tx");
const url_1 = require("../utils/url");
async function create_object(api, params) {
    const { creditToken, OIDcontrollerCap, object_type, product_url, product_img_url, description, op_code, immutable_metadata, mutable_metadata, geo_location, } = params;
    const env = await api.env();
    const gasBudget = api.gasBudget;
    // IMPORTANT: Move checks prefixes using std::string::substring with the on-chain linked_domain length.
    // If the client passes a bare URL origin like "https://example.com" while linked_domain is stored as
    // "https://example.com/", substring will abort with out-of-bounds.
    const safeProductUrl = (0, url_1.ensureTrailingSlashForOriginOnly)(product_url);
    const tx = new transactions_1.Transaction();
    const moveFunction = env.packageID + "::oid_object::create_object";
    tx.moveCall({
        arguments: [
            tx.object(creditToken),
            tx.object(env.policy),
            tx.object(OIDcontrollerCap),
            tx.pure.string(String(object_type ?? "")),
            tx.pure.string(String(safeProductUrl ?? "")),
            tx.pure.string(String(product_img_url ?? "")),
            tx.pure.string(String(description ?? "")),
            tx.pure.string(String(op_code ?? "")),
            tx.pure.string((0, env_1.asJsonString)(immutable_metadata)),
            tx.pure.string((0, env_1.asJsonString)(mutable_metadata)),
            tx.pure.string(String(geo_location ?? "")),
            tx.object("0x6"),
        ],
        target: moveFunction,
    });
    tx.setGasBudget(gasBudget);
    tx.setSender(env.sender);
    const r = await (0, tx_1.signAndExecute)(env.client, env.keyPair, tx, {
        network: env.network,
        gasBudget,
        useGasStation: api.useGasStation,
        gasStation: api.gasStation,
        onExecuted: api.onTxExecuted,
    });
    if (r?.success)
        r.createdObjectId = r.txEffect?.effects?.created?.[0]?.reference?.objectId;
    return r;
}
async function delete_object(api, params) {
    const { creditToken, controllerCap, object } = params;
    const env = await api.env();
    const gasBudget = api.gasBudget;
    const tx = new transactions_1.Transaction();
    const moveFunction = env.packageID + "::oid_object::delete_object";
    tx.moveCall({
        arguments: [tx.object(creditToken), tx.object(env.policy), tx.object(controllerCap), tx.object(object)],
        target: moveFunction,
    });
    tx.setGasBudget(gasBudget);
    tx.setSender(env.sender);
    const r = await (0, tx_1.signAndExecute)(env.client, env.keyPair, tx, {
        network: env.network,
        gasBudget,
        useGasStation: api.useGasStation,
        gasStation: api.gasStation,
        onExecuted: api.onTxExecuted,
    });
    return r;
}
async function update_agent_did(api, params) {
    const { controllerCap, object, new_agent_did } = params;
    const env = await api.env();
    const gasBudget = api.gasBudget;
    const tx = new transactions_1.Transaction();
    const moveFunction = env.packageID + "::oid_object::update_agent_did";
    tx.moveCall({
        arguments: [
            tx.object(controllerCap),
            tx.object(object),
            tx.pure.string(String(new_agent_did ?? "")),
            tx.object(utils_1.IOTA_CLOCK_OBJECT_ID),
        ],
        target: moveFunction,
    });
    tx.setGasBudget(gasBudget);
    tx.setSender(env.sender);
    const r = await (0, tx_1.signAndExecute)(env.client, env.keyPair, tx, {
        network: env.network,
        gasBudget,
        useGasStation: api.useGasStation,
        gasStation: api.gasStation,
        onExecuted: api.onTxExecuted,
    });
    return r;
}
async function update_geo_location(api, params) {
    const { controllerCap, object, new_location } = params;
    const env = await api.env();
    const gasBudget = api.gasBudget;
    const tx = new transactions_1.Transaction();
    const moveFunction = env.packageID + "::oid_object::update_geolocation";
    tx.moveCall({
        arguments: [
            tx.object(controllerCap),
            tx.object(object),
            tx.pure.string(String(new_location ?? "")),
            tx.object(utils_1.IOTA_CLOCK_OBJECT_ID),
        ],
        target: moveFunction,
    });
    tx.setGasBudget(gasBudget);
    tx.setSender(env.sender);
    const r = await (0, tx_1.signAndExecute)(env.client, env.keyPair, tx, {
        network: env.network,
        gasBudget,
        useGasStation: api.useGasStation,
        gasStation: api.gasStation,
        onExecuted: api.onTxExecuted,
    });
    return r;
}
// Back-compat alias (same Move target)
async function update_geolocation(api, params) {
    const { controllerCap, object, new_location } = params;
    const env = await api.env();
    const gasBudget = api.gasBudget;
    const tx = new transactions_1.Transaction();
    const moveFunction = env.packageID + "::oid_object::update_geolocation";
    tx.moveCall({
        arguments: [
            tx.object(controllerCap),
            tx.object(object),
            tx.pure.string(String(new_location ?? "")),
            tx.object(utils_1.IOTA_CLOCK_OBJECT_ID),
        ],
        target: moveFunction,
    });
    tx.setGasBudget(gasBudget);
    tx.setSender(env.sender);
    const r = await (0, tx_1.signAndExecute)(env.client, env.keyPair, tx, {
        network: env.network,
        gasBudget,
        useGasStation: api.useGasStation,
        gasStation: api.gasStation,
        onExecuted: api.onTxExecuted,
    });
    return r;
}
async function update_object(api, params) {
    const { creditToken, controllerCap, object, new_product_img_url, new_description } = params;
    const env = await api.env();
    const gasBudget = api.gasBudget;
    const tx = new transactions_1.Transaction();
    const moveFunction = env.packageID + "::oid_object::update_object";
    tx.moveCall({
        arguments: [
            tx.object(creditToken),
            tx.object(env.policy),
            tx.object(controllerCap),
            tx.object(object),
            tx.pure.string(String(new_product_img_url ?? "")),
            tx.pure.string(String(new_description ?? "")),
            tx.object("0x6"),
        ],
        target: moveFunction,
    });
    tx.setGasBudget(gasBudget);
    tx.setSender(env.sender);
    const r = await (0, tx_1.signAndExecute)(env.client, env.keyPair, tx, {
        network: env.network,
        gasBudget,
        useGasStation: api.useGasStation,
        gasStation: api.gasStation,
        onExecuted: api.onTxExecuted,
    });
    return r;
}
async function update_object_did(api, params) {
    const { creditToken, controllerCap, object, new_object_did } = params;
    const env = await api.env();
    const gasBudget = api.gasBudget;
    const tx = new transactions_1.Transaction();
    const moveFunction = env.packageID + "::oid_object::update_object_did";
    tx.moveCall({
        arguments: [
            tx.object(creditToken),
            tx.object(env.policy),
            tx.object(controllerCap),
            tx.object(object),
            tx.pure.string(String(new_object_did ?? "")),
            tx.object("0x6"),
        ],
        target: moveFunction,
    });
    tx.setGasBudget(gasBudget);
    tx.setSender(env.sender);
    const r = await (0, tx_1.signAndExecute)(env.client, env.keyPair, tx, {
        network: env.network,
        gasBudget,
        useGasStation: api.useGasStation,
        gasStation: api.gasStation,
        onExecuted: api.onTxExecuted,
    });
    return r;
}
async function update_object_mutable_metadata(api, params) {
    const { creditToken, controllerCap, object, new_mutable_metadata } = params;
    const env = await api.env();
    const gasBudget = api.gasBudget;
    const tx = new transactions_1.Transaction();
    const moveFunction = env.packageID + "::oid_object::update_object_mutable_metadata";
    tx.moveCall({
        arguments: [
            tx.object(creditToken),
            tx.object(env.policy),
            tx.object(controllerCap),
            tx.object(object),
            tx.pure.string((0, env_1.asJsonString)(new_mutable_metadata)),
            tx.object(utils_1.IOTA_CLOCK_OBJECT_ID),
        ],
        target: moveFunction,
    });
    tx.setGasBudget(gasBudget);
    tx.setSender(env.sender);
    const r = await (0, tx_1.signAndExecute)(env.client, env.keyPair, tx, {
        network: env.network,
        gasBudget,
        useGasStation: api.useGasStation,
        gasStation: api.gasStation,
        onExecuted: api.onTxExecuted,
    });
    return r;
}
async function update_op_code(api, params) {
    const { creditToken, controllerCap, object, new_op_code } = params;
    const env = await api.env();
    const gasBudget = api.gasBudget;
    const tx = new transactions_1.Transaction();
    const moveFunction = env.packageID + "::oid_object::update_op_code";
    tx.moveCall({
        arguments: [
            tx.object(creditToken),
            tx.object(env.policy),
            tx.object(controllerCap),
            tx.object(object),
            tx.pure.string(String(new_op_code ?? "")),
            tx.object("0x6"),
        ],
        target: moveFunction,
    });
    tx.setGasBudget(gasBudget);
    tx.setSender(env.sender);
    const r = await (0, tx_1.signAndExecute)(env.client, env.keyPair, tx, {
        network: env.network,
        gasBudget,
        useGasStation: api.useGasStation,
        gasStation: api.gasStation,
        onExecuted: api.onTxExecuted,
    });
    return r;
}
async function update_owner_did(api, params) {
    const { controllerCap, object, new_owner_did } = params;
    const env = await api.env();
    const gasBudget = api.gasBudget;
    const tx = new transactions_1.Transaction();
    const moveFunction = env.packageID + "::oid_object::update_owner_did";
    tx.moveCall({
        arguments: [
            tx.object(controllerCap),
            tx.object(object),
            tx.pure.string(String(new_owner_did ?? "")),
            tx.object(utils_1.IOTA_CLOCK_OBJECT_ID),
        ],
        target: moveFunction,
    });
    tx.setGasBudget(gasBudget);
    tx.setSender(env.sender);
    const r = await (0, tx_1.signAndExecute)(env.client, env.keyPair, tx, {
        network: env.network,
        gasBudget,
        useGasStation: api.useGasStation,
        gasStation: api.gasStation,
        onExecuted: api.onTxExecuted,
    });
    return r;
}
//# sourceMappingURL=object.js.map