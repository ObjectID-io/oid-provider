"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.alert_message = alert_message;
exports.anonymous_message = anonymous_message;
exports.control_message = control_message;
exports.creator_message = creator_message;
exports.message = message;
const transactions_1 = require("@iota/iota-sdk/transactions");
const tx_1 = require("../utils/tx");
async function alert_message(api, params) {
    const { creditToken, controllerCap, object, message, message_code, geolocation, link } = params;
    const env = await api.env();
    const gasBudget = api.gasBudget;
    const tx = new transactions_1.Transaction();
    const moveFunction = env.packageID + "::oid_object::alert_message";
    tx.moveCall({
        arguments: [
            tx.object(creditToken),
            tx.object(env.policy),
            tx.object(controllerCap),
            tx.object(object),
            tx.pure.string(String(message ?? "")),
            tx.pure.u16(Number(message_code)),
            tx.pure.string(String(geolocation ?? "")),
            tx.pure.string(String(link ?? "")),
        ],
        target: moveFunction,
    });
    tx.setGasBudget(gasBudget);
    tx.setSender(env.sender);
    const r = await (0, tx_1.signAndExecute)(env.client, env.keyPair, tx, {
        network: env.network,
        gasBudget,
        useGasStation: api.useGasStation,
        gasStation: api.gasStation,
        onExecuted: api.onTxExecuted,
    });
    return r;
}
async function anonymous_message(api, params) {
    const { object, geolocation } = params;
    const env = await api.env();
    const gasBudget = api.gasBudget;
    const tx = new transactions_1.Transaction();
    const moveFunction = env.packageID + "::oid_object::anonymous_message";
    tx.moveCall({
        arguments: [tx.object(object), tx.pure.string(String(geolocation ?? ""))],
        target: moveFunction,
    });
    tx.setGasBudget(gasBudget);
    tx.setSender(env.sender);
    const r = await (0, tx_1.signAndExecute)(env.client, env.keyPair, tx, {
        network: env.network,
        gasBudget,
        useGasStation: api.useGasStation,
        gasStation: api.gasStation,
        onExecuted: api.onTxExecuted,
    });
    return r;
}
async function control_message(api, params) {
    const { creditToken, controllerCap, object, message, message_code, geolocation, link } = params;
    const env = await api.env();
    const gasBudget = api.gasBudget;
    const tx = new transactions_1.Transaction();
    const moveFunction = env.packageID + "::oid_object::control_message";
    tx.moveCall({
        arguments: [
            tx.object(creditToken),
            tx.object(env.policy),
            tx.object(controllerCap),
            tx.object(object),
            tx.pure.string(String(message ?? "")),
            tx.pure.u16(Number(message_code)),
            tx.pure.string(String(geolocation ?? "")),
            tx.pure.string(String(link ?? "")),
        ],
        target: moveFunction,
    });
    tx.setGasBudget(gasBudget);
    tx.setSender(env.sender);
    const r = await (0, tx_1.signAndExecute)(env.client, env.keyPair, tx, {
        network: env.network,
        gasBudget,
        useGasStation: api.useGasStation,
        gasStation: api.gasStation,
        onExecuted: api.onTxExecuted,
    });
    return r;
}
async function creator_message(api, params) {
    const { creditToken, controllerCap, object, message, message_code, geolocation, link } = params;
    const env = await api.env();
    const gasBudget = api.gasBudget;
    const tx = new transactions_1.Transaction();
    const moveFunction = env.packageID + "::oid_object::creator_message";
    tx.moveCall({
        arguments: [
            tx.object(creditToken),
            tx.object(env.policy),
            tx.object(controllerCap),
            tx.object(object),
            tx.pure.string(String(message ?? "")),
            tx.pure.u16(Number(message_code)),
            tx.pure.string(String(geolocation ?? "")),
            tx.pure.string(String(link ?? "")),
        ],
        target: moveFunction,
    });
    tx.setGasBudget(gasBudget);
    tx.setSender(env.sender);
    const r = await (0, tx_1.signAndExecute)(env.client, env.keyPair, tx, {
        network: env.network,
        gasBudget,
        useGasStation: api.useGasStation,
        gasStation: api.gasStation,
        onExecuted: api.onTxExecuted,
    });
    return r;
}
async function message(api, params) {
    const { creditToken, controllerCap, object, message_code, message, geolocation, link } = params;
    const env = await api.env();
    const gasBudget = api.gasBudget;
    const tx = new transactions_1.Transaction();
    const moveFunction = env.packageID + "::oid_object::message";
    tx.moveCall({
        arguments: [
            tx.object(creditToken),
            tx.object(env.policy),
            tx.object(controllerCap),
            tx.object(object),
            tx.pure.u16(Number(message_code)),
            tx.pure.string(String(message ?? "")),
            tx.pure.string(String(geolocation ?? "")),
            tx.pure.string(String(link ?? "")),
        ],
        target: moveFunction,
    });
    tx.setGasBudget(gasBudget);
    tx.setSender(env.sender);
    const r = await (0, tx_1.signAndExecute)(env.client, env.keyPair, tx, {
        network: env.network,
        gasBudget,
        useGasStation: api.useGasStation,
        gasStation: api.gasStation,
        onExecuted: api.onTxExecuted,
    });
    return r;
}
//# sourceMappingURL=objectMessages.js.map