"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.create_event = create_event;
exports.delete_event = delete_event;
exports.update_event_mutable_metadata = update_event_mutable_metadata;
const transactions_1 = require("@iota/iota-sdk/transactions");
const utils_1 = require("@iota/iota-sdk/utils");
const env_1 = require("../env");
const tx_1 = require("../utils/tx");
const getObject_1 = require("../utils/getObject");
async function create_event(api, params) {
    const { creditToken, controllerCap, object, event_type, immutable_metadata, mutable_metadata } = params;
    const env = await api.env();
    const gasBudget = api.gasBudget;
    const tx = new transactions_1.Transaction();
    const moveFunction = env.packageID + "::oid_object::create_event";
    tx.moveCall({
        arguments: [
            tx.object(creditToken),
            tx.object(env.policy),
            tx.object(controllerCap),
            tx.object(object),
            tx.pure.string(String(event_type ?? "")),
            tx.pure.string((0, env_1.asJsonString)(immutable_metadata)),
            tx.pure.string((0, env_1.asJsonString)(mutable_metadata)),
            tx.object(utils_1.IOTA_CLOCK_OBJECT_ID),
        ],
        target: moveFunction,
    });
    tx.setGasBudget(gasBudget);
    tx.setSender(env.sender);
    const r = await (0, tx_1.signAndExecute)(env.client, env.keyPair, tx, {
        network: env.network,
        gasBudget,
        useGasStation: api.useGasStation,
        gasStation: api.gasStation,
        onExecuted: api.onTxExecuted,
    });
    return r;
}
async function delete_event(api, params) {
    const { creditToken, controllerCap, object, event } = params;
    const env = await api.env();
    const gasBudget = api.gasBudget ?? 10_000_000;
    const tx = new transactions_1.Transaction();
    const moveFunction = `${env.packageID}::oid_object::delete_event`;
    tx.moveCall({
        target: moveFunction,
        arguments: [
            tx.object(creditToken),
            tx.object(env.policy),
            tx.object(controllerCap),
            tx.object(object),
            tx.object(event),
        ],
    });
    tx.setGasBudget(gasBudget);
    tx.setSender(env.sender);
    const r = await (0, tx_1.signAndExecute)(env.client, env.keyPair, tx, {
        network: env.network,
        gasBudget,
        useGasStation: api.useGasStation,
        gasStation: api.gasStation,
        onExecuted: api.onTxExecuted,
    });
    // Keep old behavior: throw on explicit failure
    const digest = String(r?.txDigest ?? r?.digest ?? r?.transactionDigest ?? "").trim();
    if (r?.success === false) {
        const detail = String(r?.error ?? r?.status?.error ?? r?.status?.errorMessage ?? "Transaction failed");
        const err = new Error(`${detail}${digest ? ` (tx ${digest})` : ""}`);
        err.digest = digest;
        err.raw = r;
        throw err;
    }
    return r;
}
async function update_event_mutable_metadata(api, params) {
    const { creditToken, controllerCap, event, new_mutable_metadata } = params;
    const env = await api.env();
    const gasBudget = api.gasBudget ?? 10_000_000;
    const objectData = (await (0, getObject_1.getObject)(env.client, event));
    const owner = objectData?.owner ?? objectData?.data?.owner ?? null;
    const eventOwner = (typeof owner?.ObjectOwner === "string"
        ? owner.ObjectOwner
        : (owner?.ObjectOwner?.objectId ?? owner?.ObjectOwner?.id)) ??
        owner?.AddressOwner ??
        null;
    const tx = new transactions_1.Transaction();
    const moveFunction = env.packageID + "::oid_object::update_event_mutable_metadata";
    tx.moveCall({
        target: moveFunction,
        arguments: [
            tx.object(creditToken),
            tx.object(env.policy),
            tx.object(controllerCap),
            tx.object(eventOwner),
            tx.object(event),
            tx.pure.string((0, env_1.asJsonString)(new_mutable_metadata)),
        ],
    });
    tx.setGasBudget(gasBudget);
    tx.setSender(env.sender);
    const r = await (0, tx_1.signAndExecute)(env.client, env.keyPair, tx, {
        network: env.network,
        gasBudget,
        useGasStation: api.useGasStation,
        gasStation: api.gasStation,
        onExecuted: api.onTxExecuted,
    });
    return r;
}
//# sourceMappingURL=event.js.map