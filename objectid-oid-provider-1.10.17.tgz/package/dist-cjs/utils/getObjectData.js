"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getObjectData = getObjectData;
const getObject_1 = require("./getObject");
const debug = false;
async function getObjectData(client, network, oid) {
    try {
        const localNetwork = network === "testnet" ? "testnet" : "mainnet";
        const object = (await (0, getObject_1.getObject)(client, oid));
        if (object && object.content?.fields) {
            return {
                fields: object.content.fields,
                type: object.type,
                id: oid,
                network: localNetwork,
            };
        }
        else {
            console.warn(`Object ${oid} on network ${localNetwork} found, but content or fields are missing.`);
            return null;
        }
    }
    catch (error) {
        if (debug)
            console.error(`Error fetching or processing object ${oid} on network ${network}:`, error);
        return null;
    }
}
//# sourceMappingURL=getObjectData.js.map