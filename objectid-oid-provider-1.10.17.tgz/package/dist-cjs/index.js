"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.asJsonString = exports.DEFAULT_SHARED_CONFIG_OBJECT_ID = exports.DEFAULT_CONFIG_PACKAGE_IDS = exports.dlvcProxyUrl = exports.configType = exports.findUserConfigObjectId = exports.loadEffectiveConfig = exports.loadConfigJsonByObjectId = exports.loadPublicConfig = exports.useObjectIDSession = exports.useOptionalObjectId = exports.useObjectId = exports.ObjectID = exports.createOid = exports.createObjectIdApi = void 0;
var api_1 = require("./api");
Object.defineProperty(exports, "createObjectIdApi", { enumerable: true, get: function () { return api_1.createObjectIdApi; } });
// OID high-level wrapper
var oid_1 = require("./oid");
Object.defineProperty(exports, "createOid", { enumerable: true, get: function () { return oid_1.createOid; } });
// React provider + hooks
var react_1 = require("./react");
Object.defineProperty(exports, "ObjectID", { enumerable: true, get: function () { return react_1.ObjectID; } });
Object.defineProperty(exports, "useObjectId", { enumerable: true, get: function () { return react_1.useObjectId; } });
Object.defineProperty(exports, "useOptionalObjectId", { enumerable: true, get: function () { return react_1.useOptionalObjectId; } });
Object.defineProperty(exports, "useObjectIDSession", { enumerable: true, get: function () { return react_1.useObjectIDSession; } });
var config_1 = require("./onchain/config");
Object.defineProperty(exports, "loadPublicConfig", { enumerable: true, get: function () { return config_1.loadPublicConfig; } });
Object.defineProperty(exports, "loadConfigJsonByObjectId", { enumerable: true, get: function () { return config_1.loadConfigJsonByObjectId; } });
Object.defineProperty(exports, "loadEffectiveConfig", { enumerable: true, get: function () { return config_1.loadEffectiveConfig; } });
Object.defineProperty(exports, "findUserConfigObjectId", { enumerable: true, get: function () { return config_1.findUserConfigObjectId; } });
Object.defineProperty(exports, "configType", { enumerable: true, get: function () { return config_1.configType; } });
Object.defineProperty(exports, "dlvcProxyUrl", { enumerable: true, get: function () { return config_1.dlvcProxyUrl; } });
var defaults_1 = require("./onchain/defaults");
Object.defineProperty(exports, "DEFAULT_CONFIG_PACKAGE_IDS", { enumerable: true, get: function () { return defaults_1.DEFAULT_CONFIG_PACKAGE_IDS; } });
Object.defineProperty(exports, "DEFAULT_SHARED_CONFIG_OBJECT_ID", { enumerable: true, get: function () { return defaults_1.DEFAULT_SHARED_CONFIG_OBJECT_ID; } });
// Tx methods + their exported Params types (for IntelliSense)
__exportStar(require("./methods"), exports);
// Utilities
var env_1 = require("./env");
Object.defineProperty(exports, "asJsonString", { enumerable: true, get: function () { return env_1.asJsonString; } });
//# sourceMappingURL=index.js.map